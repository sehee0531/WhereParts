class Variables {
    //DBList 검색항목 리스트
    /*static getNames() {
        return [
            {value:"All",title:"전체"},
        ];
    }*/

    static getNumbers() {
        return [
            {value:""},
        ];
    }

    /*static getHashTags() {
        return [
            {value:"All",title:"전체"},
        ];
    }*/
   
}

export default Variables;