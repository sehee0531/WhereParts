import React, { Component } from 'react';
import { View } from 'react-native';

import { styles } from "../styles/vision_camera_style";

import CameraX from '../util/camera_x';
import WebServiceManager from "../util/webservice_manager";
import Constant from "../util/constatnt_variables";

export default class CompanyCamera extends Component {
    constructor(props) {
        super(props);

        this.cutImageStyle={
            top:'11%', 
            left:'9%',
            right:'9%',
            bottom:'29%',
            position:'absolute',
            zIndex:2, 
            borderColor:'white',
        };
    }

    async callCompanyInfoAPI(imageData) {
        let manager = new WebServiceManager(Constant.serviceURL + "/GetCompanyInfo", "post");
        manager.addBinaryData("file", imageData);
        let response = await manager.start();
        if (response.ok) {
            return response.json();
        }
    }

    onCutImageListener=(uri) => {
        console.log('cut image : ',uri);
        console.log(this.props);

        const fileData = {
            uri: uri,
            type: "image/jpeg",
            name: 'photo.jpg',
        }

        this.callCompanyInfoAPI(fileData).then((response) => {
            console.log("company info", response);
            this.props.route.params.onResultListener(response,uri);
            //this.props.navigation.pop();
        })
    }

    onCapturedListener=(uri)=> {
        console.log('original image : ',uri);
    }

    render() {
        return(
            <View style={styles.container}>
                <CameraX autoClose={true} blur={true} cameraBorder={true} navigation={this.props.navigation} cutImageStyle={this.cutImageStyle}  onCapturedListener={this.onCapturedListener} onCutImageListener={this.onCutImageListener} />
            </View>
        );
    }
}