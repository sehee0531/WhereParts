import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({

    goodsInfoView:{
        height:'30%',
        backgroundColor:'gray'
    },
    payInfoView:{
        flex:2,
    },
  
});