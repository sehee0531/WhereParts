import React, { Component } from 'react';
import { View,Text,ScrollView,TouchableOpacity } from 'react-native';

import { template } from "../styles/template/page_style";

class ShopHistory extends Component {
    constructor(props) {
        super(props);
    }
  
    render() {
        return (
            <View style={template.total_container}>
            <ScrollView>
               
           </ScrollView>
       </View>
        );
    }
}
export default ShopHistory;